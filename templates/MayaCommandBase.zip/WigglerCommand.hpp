/////////////////////////////////////////////////////
//[Module name]
//
//Copyright (c) 2017 Shotaro Shirao
//White Library
/////////////////////////////////////////////////////

#pragma once
#ifndef __HPP_
#define __HPP_

#include <maya/MPxCommand.h>
#include <maya/MArgList.h>

namespace __rep__ {

	/** ___replace___ CLASS
	* ����
	*/
	class ___replace___ : public MPxCommand{
	public:
		//////////////////////////////
		// PUBLIC MEMBER CONSTANT
		//////////////////////////////


		//////////////////////////////
		// PUBLIC MEMBER VALIABLES
		//////////////////////////////


		//////////////////////////////
		// PUBLIC MEMBER FUNCTION
		//////////////////////////////

		/** Constructor
		*/
		___replace___();

		/** Destructor
		*/
		~___replace___();

		virtual MStatus doIt(const MArgList& args) override;
		
		static void* creator();

	protected:

	private:

	};

};

inline void * __rep__::___replace___::creator()
{
	return new ___replace___();
}

#endif //end of include guard
